# Tests

Requires [zsh-test-runner](https://github.com/olets/zsh-test-runner).

Run with

```shell
. ./index.ztr.zsh
```
